import { useState, useReducer, useRef, useCallback } from 'react'
import FullCalendar from '@fullcalendar/react'
import timeGridPlugin from '@fullcalendar/timegrid'
import dayGridPlugin from '@fullcalendar/daygrid'
import interactionPlugin from '@fullcalendar/interaction'
import type { EventContentArg } from '@fullcalendar/core'

// ─── Types ────────────────────────────────────────────────────────────────────

type BlockType = 'event' | 'task' | 'meal' | 'cook' | 'travel' | 'free' | 'slack'
type TransportMode = 'bike' | 'walking' | 'public' | 'car'
const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] as const
type Day = typeof DAYS[number]

interface Block {
  id: string; type: BlockType; title: string; start: string; end: string
  task_id?: string; location?: string; locked?: boolean
}
interface Task { id: string; text: string }
interface WeeklyCommitment { id: string; name: string; days: Day[]; time: string; minutes: number }
interface Commute { address: string; mode: TransportMode }
interface Settings {
  timezone: string; horizon_start: string; horizon_days: number
  day_start: string; day_end: string
  lunch_min: number; dinner_min: number
  cooking_mode: 'daily' | 'batch' | 'none'; batch_per_week: number
  transition_minutes: number; lost_time_pct: number; free_time_min_per_day: number
}

type Status = 'idle' | 'allocating' | 'placing' | 'done' | 'error'

interface AppState {
  events: Block[]; tasks: Task[]; weeklyCommitments: WeeklyCommitment[]
  commute: Commute; settings: Settings; blocks: Block[]
  warnings: string[]; status: Status; errorMsg: string | null; icsFileName: string | null
}

type Action =
  | { type: 'SET_EVENTS'; events: Block[]; fileName: string }
  | { type: 'ADD_TASK'; task: Task }
  | { type: 'REMOVE_TASK'; id: string }
  | { type: 'ADD_COMMITMENT'; commitment: WeeklyCommitment }
  | { type: 'REMOVE_COMMITMENT'; id: string }
  | { type: 'SET_COMMUTE'; commute: Partial<Commute> }
  | { type: 'UPDATE_SETTING'; key: keyof Settings; value: string | number }
  | { type: 'SET_STATUS'; status: Status; errorMsg?: string }
  | { type: 'SET_BLOCKS'; blocks: Block[]; warnings: string[] }
  | { type: 'REMOVE_BLOCK'; id: string }
  | { type: 'TOGGLE_LOCK'; id: string }

const defaultSettings: Settings = {
  timezone: 'Europe/Amsterdam', horizon_start: new Date().toISOString().slice(0, 10),
  horizon_days: 7, day_start: '08:00', day_end: '22:30',
  lunch_min: 30, dinner_min: 30,
  cooking_mode: 'batch', batch_per_week: 3,
  transition_minutes: 15, lost_time_pct: 15, free_time_min_per_day: 60,
}

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'SET_EVENTS': return { ...state, events: action.events, blocks: [], icsFileName: action.fileName }
    case 'ADD_TASK': return { ...state, tasks: [...state.tasks, action.task] }
    case 'REMOVE_TASK': return { ...state, tasks: state.tasks.filter(t => t.id !== action.id) }
    case 'ADD_COMMITMENT': return { ...state, weeklyCommitments: [...state.weeklyCommitments, action.commitment] }
    case 'REMOVE_COMMITMENT': return { ...state, weeklyCommitments: state.weeklyCommitments.filter(c => c.id !== action.id) }
    case 'SET_COMMUTE': return { ...state, commute: { ...state.commute, ...action.commute } }
    case 'UPDATE_SETTING': return { ...state, settings: { ...state.settings, [action.key]: action.value } }
    case 'SET_STATUS': return { ...state, status: action.status, errorMsg: action.errorMsg ?? null }
    case 'SET_BLOCKS': return { ...state, blocks: action.blocks, warnings: action.warnings, status: 'done' }
    case 'REMOVE_BLOCK': return { ...state, blocks: state.blocks.filter(b => b.id !== action.id) }
    case 'TOGGLE_LOCK': return { ...state, blocks: state.blocks.map(b => b.id === action.id ? { ...b, locked: !b.locked } : b) }
    default: return state
  }
}

// ─── Block palette ────────────────────────────────────────────────────────────

const PALETTE: Record<BlockType, { bg: string; dot: string; text: string; label: string }> = {
  event:  { bg: 'rgba(148,163,184,0.12)', dot: '#94a3b8', text: '#cbd5e1', label: 'Event' },
  task:   { bg: 'rgba(99,102,241,0.15)',  dot: '#6366f1', text: '#a5b4fc', label: 'Task' },
  meal:   { bg: 'rgba(251,191,36,0.12)',  dot: '#f59e0b', text: '#fcd34d', label: 'Meal' },
  cook:   { bg: 'rgba(249,115,22,0.12)',  dot: '#f97316', text: '#fdba74', label: 'Cook' },
  travel: { bg: 'rgba(167,139,250,0.12)', dot: '#a78bfa', text: '#c4b5fd', label: 'Travel' },
  free:   { bg: 'rgba(34,197,94,0.10)',   dot: '#22c55e', text: '#86efac', label: 'Free' },
  slack:  { bg: 'rgba(75,85,99,0.15)',    dot: '#6b7280', text: '#9ca3af', label: 'Slack' },
}

// ─── Mock data ────────────────────────────────────────────────────────────────

function getMockBlocks(): Block[] {
  const today = new Date(); today.setHours(0, 0, 0, 0)
  const d = (days: number, h: number, m = 0) => {
    const dt = new Date(today); dt.setDate(dt.getDate() + days); dt.setHours(h, m); return dt.toISOString()
  }
  return [
    { id: 'e1', type: 'event', title: 'Lecture: Data Systems', start: d(0, 9), end: d(0, 11) },
    { id: 'e2', type: 'event', title: 'Group Meeting', start: d(1, 14), end: d(1, 15, 30) },
    { id: 'e3', type: 'event', title: 'Lab Session', start: d(3, 10), end: d(3, 12) },
    { id: 't1', type: 'task', title: 'DB Assignment', start: d(0, 13), end: d(0, 15) },
    { id: 't2', type: 'task', title: 'Reading: Ch. 4–6', start: d(1, 9), end: d(1, 11) },
    { id: 't3', type: 'task', title: 'Project Slides', start: d(2, 15), end: d(2, 17) },
    { id: 't4', type: 'task', title: 'Essay Draft', start: d(4, 9), end: d(4, 11) },
    { id: 'm1', type: 'meal', title: 'Lunch', start: d(0, 12), end: d(0, 12, 30) },
    { id: 'm2', type: 'meal', title: 'Dinner', start: d(0, 18, 30), end: d(0, 19) },
    { id: 'm3', type: 'meal', title: 'Lunch', start: d(1, 12), end: d(1, 12, 30) },
    { id: 'm4', type: 'meal', title: 'Dinner', start: d(1, 18, 30), end: d(1, 19) },
    { id: 'm5', type: 'meal', title: 'Lunch', start: d(2, 12), end: d(2, 12, 30) },
    { id: 'c1', type: 'cook', title: 'Cook dinner', start: d(0, 17, 45), end: d(0, 18, 30) },
    { id: 'c2', type: 'cook', title: 'Cook dinner', start: d(2, 17, 45), end: d(2, 18, 30) },
    { id: 'v1', type: 'travel', title: 'Travel → Campus', start: d(0, 8, 30), end: d(0, 9) },
    { id: 'v2', type: 'travel', title: 'Travel → Home', start: d(0, 11), end: d(0, 11, 30) },
    { id: 'f1', type: 'free', title: 'Free time', start: d(0, 20), end: d(0, 21) },
    { id: 'f2', type: 'free', title: 'Free time', start: d(1, 20), end: d(1, 21) },
    { id: 'f3', type: 'free', title: 'Free time', start: d(2, 20), end: d(2, 21) },
  ]
}

// ─── Custom event renderer ────────────────────────────────────────────────────

function CalendarEvent({ info }: { info: EventContentArg }) {
  const block: Block = info.event.extendedProps.block
  const p = PALETTE[block.type]
  const durationMin = (new Date(block.end).getTime() - new Date(block.start).getTime()) / 60000
  const compact = durationMin <= 35
  const startStr = new Date(block.start).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  return (
    <div style={{
      height: '100%', padding: compact ? '2px 5px' : '4px 6px',
      display: 'flex', flexDirection: compact ? 'row' : 'column',
      alignItems: compact ? 'center' : 'flex-start', gap: compact ? 4 : 2,
      overflow: 'hidden', background: p.bg, borderLeft: `2px solid ${p.dot}`, borderRadius: 4,
    }}>
      <span style={{
        fontSize: 11, fontWeight: 500, color: p.text, lineHeight: 1.3,
        overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        flex: compact ? '1 1 auto' : undefined, minWidth: 0,
      }}>{block.locked ? '🔒 ' : ''}{block.title}</span>
      {!compact && (
        <span style={{
          fontFamily: "'DM Mono', monospace", fontSize: 9, color: p.dot,
          opacity: 0.8, letterSpacing: '0.02em', whiteSpace: 'nowrap',
        }}>{startStr}</span>
      )}
    </div>
  )
}

// ─── Sidebar primitives ───────────────────────────────────────────────────────

function SectionToggle({ label, count, expanded, onClick }: {
  label: string; count?: number; expanded: boolean; onClick: () => void
}) {
  return (
    <button onClick={onClick} style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      width: '100%', padding: '11px 0', background: 'none', border: 'none', cursor: 'pointer',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <span style={{
          fontFamily: "'DM Mono', monospace", fontSize: 9, fontWeight: 500,
          letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--fg3)',
        }}>{label}</span>
        {count !== undefined && (
          <span style={{
            fontSize: 9, fontFamily: "'DM Mono', monospace",
            background: 'var(--surface2)', color: 'var(--fg3)', borderRadius: 3, padding: '1px 5px',
          }}>{count}</span>
        )}
      </div>
      <svg width="10" height="10" viewBox="0 0 10 10" fill="none"
        style={{ transition: 'transform 0.2s', transform: expanded ? 'rotate(180deg)' : 'none', flexShrink: 0 }}>
        <path d="M2 3.5l3 3 3-3" stroke="var(--fg3)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    </button>
  )
}

function Rule() {
  return <div style={{ height: 1, background: 'var(--border)', margin: '2px 0' }} />
}

function FieldLabel({ children }: { children: React.ReactNode }) {
  return <div style={{ fontSize: 10, color: 'var(--fg3)', marginBottom: 4 }}>{children}</div>
}

const inp: React.CSSProperties = {
  width: '100%', background: 'var(--surface)', border: '1px solid var(--border2)',
  borderRadius: 'var(--radius-sm)', padding: '6px 9px', fontSize: 11,
  color: 'var(--fg)', fontFamily: "'DM Sans', sans-serif", outline: 'none', boxSizing: 'border-box',
}

const inpNarrow: React.CSSProperties = { ...inp, width: '100%' }

// ─── App ──────────────────────────────────────────────────────────────────────

export default function App() {
  const [state, dispatch] = useReducer(reducer, {
    events: [], blocks: getMockBlocks(), warnings: [], status: 'done',
    errorMsg: null, icsFileName: null,
    tasks: [
      { id: '1', text: 'DB assignment, due Fri, ~3h' },
      { id: '2', text: 'Read chapters 4–6, ~2h' },
      { id: '3', text: 'Project presentation slides, due Thu' },
      { id: '4', text: 'Essay draft, ~4h, due Sun' },
    ],
    weeklyCommitments: [
      { id: 'wc1', name: 'Gym', days: ['Mon', 'Wed', 'Fri'] as Day[], time: '19:00', minutes: 60 },
    ],
    commute: { address: 'Sint Servaasklooster 35, Maastricht', mode: 'bike' },
    settings: defaultSettings,
  })

  const [newTask, setNewTask] = useState('')
  const [open, setOpen] = useState({ cal: true, commute: true, tasks: true, commitments: true, settings: true })
  const [selected, setSelected] = useState<Block | null>(null)
  const [commitDraft, setCommitDraft] = useState<{ name: string; days: Day[]; time: string; minutes: number }>({
    name: '', days: [], time: '07:00', minutes: 45,
  })
  const fileInputRef = useRef<HTMLInputElement>(null)

  const toggle = (k: keyof typeof open) => setOpen(o => ({ ...o, [k]: !o[k] }))

  const handleAddTask = () => {
    const text = newTask.trim(); if (!text) return
    dispatch({ type: 'ADD_TASK', task: { id: Date.now().toString(), text } })
    setNewTask('')
  }

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return
    dispatch({ type: 'SET_STATUS', status: 'allocating' })
    const fd = new FormData(); fd.append('file', file)
    try {
      const r = await fetch('/api/parse-ics', { method: 'POST', body: fd })
      if (!r.ok) throw new Error(await r.text())
      const d = await r.json()
      dispatch({ type: 'SET_EVENTS', events: d.events, fileName: file.name })
    } catch {
      dispatch({ type: 'SET_EVENTS', events: [], fileName: file.name })
    }
    dispatch({ type: 'SET_STATUS', status: 'idle' })
    e.target.value = ''
  }

  const toggleCommitDay = (day: Day) => {
    setCommitDraft(d => ({
      ...d,
      days: d.days.includes(day) ? d.days.filter(x => x !== day) : [...d.days, day],
    }))
  }

  const handleAddCommitment = () => {
    if (!commitDraft.name.trim() || commitDraft.days.length === 0) return
    dispatch({
      type: 'ADD_COMMITMENT',
      commitment: { id: Date.now().toString(), ...commitDraft, name: commitDraft.name.trim() },
    })
    setCommitDraft({ name: '', days: [], time: '07:00', minutes: 45 })
  }

  const handlePlan = async () => {
    dispatch({ type: 'SET_STATUS', status: 'allocating' })
    try {
      const body = {
        events: state.events, tasks: state.tasks,
        settings: {
          timezone: state.settings.timezone,
          horizon_start: state.settings.horizon_start,
          horizon_days: state.settings.horizon_days,
          day_start: state.settings.day_start,
          day_end: state.settings.day_end,
          meals: {
            lunch: { window: ['12:00', '13:30'], minutes: state.settings.lunch_min },
            dinner: { window: ['18:30', '20:00'], minutes: state.settings.dinner_min },
          },
          cooking: {
            mode: state.settings.cooking_mode,
            batch_per_week: state.settings.batch_per_week,
            cook_minutes: 45,
          },
          transition_minutes: state.settings.transition_minutes,
          travel_overrides: [],
          lost_time_pct: state.settings.lost_time_pct,
          free_time_min_per_day: state.settings.free_time_min_per_day,
        },
      }
      const r = await fetch('/api/schedule', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
      })
      dispatch({ type: 'SET_STATUS', status: 'placing' })
      if (!r.ok) throw new Error(await r.text())
      const d = await r.json()
      dispatch({ type: 'SET_BLOCKS', blocks: d.blocks, warnings: d.warnings ?? [] })
    } catch (err) {
      dispatch({ type: 'SET_STATUS', status: 'error', errorMsg: String(err) })
    }
  }

  const handleDownload = async () => {
    try {
      const r = await fetch('/api/export-ics', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ blocks: state.blocks, include_fixed: false }),
      })
      if (!r.ok) return
      const blob = await r.blob()
      const a = document.createElement('a')
      a.href = URL.createObjectURL(blob); a.download = 'scheduled-week.ics'; a.click()
    } catch { /* ignore */ }
  }

  const calEvents = useCallback(() =>
    [...state.events, ...state.blocks].map(b => ({
      id: b.id, title: b.title, start: b.start, end: b.end,
      backgroundColor: 'transparent', borderColor: 'transparent',
      textColor: PALETTE[b.type].text, extendedProps: { block: b },
    })),
  [state.events, state.blocks])

  const onEventClick = useCallback((info: { event: { extendedProps: { block: Block } } }) => {
    setSelected(info.event.extendedProps.block)
  }, [])

  const isLoading = state.status === 'allocating' || state.status === 'placing'

  const TRANSPORT: { key: TransportMode; label: string }[] = [
    { key: 'bike', label: 'Bike' },
    { key: 'walking', label: 'Walking' },
    { key: 'public', label: 'Public transport' },
    { key: 'car', label: 'Car' },
  ]

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden', background: 'var(--bg)' }}>

      {/* ── Sidebar ── */}
      <aside style={{
        width: 280, minWidth: 280, display: 'flex', flexDirection: 'column',
        background: 'var(--bg2)', borderRight: '1px solid var(--border)', overflow: 'hidden',
      }}>

        {/* Wordmark */}
        <div style={{ padding: '16px 20px 14px', borderBottom: '1px solid var(--border)', flexShrink: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{
              width: 30, height: 30, borderRadius: 8, flexShrink: 0,
              background: 'linear-gradient(135deg, #6366f1, #8b5cf6)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: '0 0 0 1px rgba(99,102,241,0.4), 0 4px 12px rgba(99,102,241,0.25)',
            }}>
              <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
                <rect x="2" y="2" width="4.5" height="4.5" rx="1" fill="white"/>
                <rect x="8.5" y="2" width="4.5" height="4.5" rx="1" fill="white" opacity="0.5"/>
                <rect x="2" y="8.5" width="4.5" height="4.5" rx="1" fill="white" opacity="0.5"/>
                <rect x="8.5" y="8.5" width="4.5" height="4.5" rx="1" fill="white" opacity="0.8"/>
              </svg>
            </div>
            <div>
              <div style={{ fontSize: 13, fontWeight: 600, letterSpacing: '-0.02em', color: 'var(--fg)', lineHeight: 1.2 }}>Gapfill</div>
              <div style={{ fontSize: 9.5, color: 'var(--fg3)', fontFamily: "'DM Mono', monospace", letterSpacing: '0.04em', marginTop: 1 }}>AI · WEEK PLANNER</div>
            </div>
          </div>
        </div>

        {/* Scrollable body */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '2px 16px 16px' }}>

          {/* ── Calendar ── */}
          <SectionToggle label="Calendar" expanded={open.cal} onClick={() => toggle('cal')} />
          {open.cal && (
            <div style={{ paddingBottom: 12 }}>
              <input ref={fileInputRef} type="file" accept=".ics" style={{ display: 'none' }} onChange={handleFile} />
              <button
                onClick={() => fileInputRef.current?.click()}
                style={{
                  display: 'flex', alignItems: 'center', gap: 8, width: '100%',
                  padding: '8px 12px', background: 'var(--surface)',
                  border: '1px dashed var(--border2)', borderRadius: 'var(--radius)',
                  cursor: 'pointer', fontSize: 11, color: 'var(--fg2)',
                  fontFamily: "'DM Sans', sans-serif", transition: 'all 0.15s',
                }}
              >
                <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
                  <path d="M6.5 1v7.5M4 4l2.5-3 2.5 3M1.5 10.5h10" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {state.icsFileName ?? 'Upload .ics calendar'}
                </span>
              </button>
              {state.events.length > 0
                ? <p style={{ marginTop: 5, fontSize: 10, color: 'var(--fg3)', fontFamily: "'DM Mono', monospace" }}>{state.events.length} events parsed</p>
                : <p style={{ marginTop: 5, fontSize: 10, color: 'var(--fg3)' }}>No calendar yet (optional).</p>
              }
            </div>
          )}

          <Rule />

          {/* ── Commute ── */}
          <SectionToggle label="Commute" expanded={open.commute} onClick={() => toggle('commute')} />
          {open.commute && (
            <div style={{ paddingBottom: 12 }}>
              <FieldLabel>Home address</FieldLabel>
              <input
                type="text"
                placeholder="Your home address"
                value={state.commute.address}
                onChange={e => dispatch({ type: 'SET_COMMUTE', commute: { address: e.target.value } })}
                style={{ ...inp, marginBottom: 8 }}
              />
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 5 }}>
                {TRANSPORT.map(({ key, label }) => (
                  <button
                    key={key}
                    onClick={() => dispatch({ type: 'SET_COMMUTE', commute: { mode: key } })}
                    style={{
                      padding: '6px 8px', fontSize: 11, fontFamily: "'DM Sans', sans-serif",
                      border: '1px solid var(--border2)', borderRadius: 'var(--radius-sm)', cursor: 'pointer',
                      background: state.commute.mode === key ? 'var(--accent)' : 'var(--surface)',
                      color: state.commute.mode === key ? '#fff' : 'var(--fg2)',
                      fontWeight: state.commute.mode === key ? 500 : 400,
                      transition: 'all 0.15s',
                    }}
                  >{label}</button>
                ))}
              </div>
              <p style={{ marginTop: 7, fontSize: 10, color: 'var(--fg3)', lineHeight: 1.5 }}>
                Travel time to each lecture comes from your calendar's locations once connected.
              </p>
            </div>
          )}

          <Rule />

          {/* ── Tasks ── */}
          <SectionToggle label="Tasks" count={state.tasks.length} expanded={open.tasks} onClick={() => toggle('tasks')} />
          {open.tasks && (
            <div style={{ paddingBottom: 12 }}>
              <div style={{ display: 'flex', gap: 5, marginBottom: 7 }}>
                <input
                  type="text" placeholder="e.g. Finish DB assignment, due Fri, ~"
                  value={newTask}
                  onChange={e => setNewTask(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleAddTask()}
                  style={{ ...inp, flex: 1 }}
                />
                <button onClick={handleAddTask} style={{
                  padding: '6px 12px', background: 'var(--accent)', border: 'none',
                  borderRadius: 'var(--radius-sm)', color: '#fff', fontSize: 11, fontWeight: 600,
                  cursor: 'pointer', flexShrink: 0, fontFamily: "'DM Sans', sans-serif", whiteSpace: 'nowrap',
                }}>Add</button>
              </div>
              {state.tasks.length === 0
                ? <p style={{ fontSize: 10, color: 'var(--fg3)', lineHeight: 1.5 }}>No tasks yet. Add one <span style={{ color: 'var(--accent2)' }}>per line</span> of your to-do list.</p>
                : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
                    {state.tasks.map(t => (
                      <div key={t.id} style={{
                        display: 'flex', alignItems: 'flex-start', gap: 7, padding: '6px 9px',
                        background: 'var(--surface)', border: '1px solid var(--border)',
                        borderRadius: 'var(--radius-sm)', fontSize: 11, color: 'var(--fg2)',
                      }}>
                        <div style={{ width: 5, height: 5, borderRadius: '50%', background: 'var(--accent)', marginTop: 4, flexShrink: 0 }} />
                        <span style={{ flex: 1, lineHeight: 1.5 }}>{t.text}</span>
                        <button onClick={() => dispatch({ type: 'REMOVE_TASK', id: t.id })}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--fg3)', padding: 0, fontSize: 14, lineHeight: 1 }}>×</button>
                      </div>
                    ))}
                  </div>
                )}
            </div>
          )}

          <Rule />

          {/* ── Weekly Commitments ── */}
          <SectionToggle label="Weekly Commitments" count={state.weeklyCommitments.length} expanded={open.commitments} onClick={() => toggle('commitments')} />
          {open.commitments && (
            <div style={{ paddingBottom: 12 }}>
              {/* Existing commitments */}
              {state.weeklyCommitments.length > 0 && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 3, marginBottom: 10 }}>
                  {state.weeklyCommitments.map(c => (
                    <div key={c.id} style={{
                      padding: '6px 9px', background: 'var(--surface)', border: '1px solid var(--border)',
                      borderRadius: 'var(--radius-sm)', fontSize: 11,
                    }}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 3 }}>
                        <span style={{ fontWeight: 500, color: 'var(--fg)' }}>{c.name}</span>
                        <button onClick={() => dispatch({ type: 'REMOVE_COMMITMENT', id: c.id })}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--fg3)', padding: 0, fontSize: 14 }}>×</button>
                      </div>
                      <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                        {c.days.map(d => (
                          <span key={d} style={{
                            fontSize: 9, fontFamily: "'DM Mono', monospace", padding: '1px 5px',
                            background: 'var(--accent-dim)', color: 'var(--accent2)',
                            borderRadius: 3, letterSpacing: '0.04em',
                          }}>{d}</span>
                        ))}
                        <span style={{ fontSize: 9, fontFamily: "'DM Mono', monospace", color: 'var(--fg3)', alignSelf: 'center' }}>
                          {c.time} · {c.minutes} min
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Draft form */}
              <input
                type="text" placeholder="Activity name (e.g. Gym)"
                value={commitDraft.name}
                onChange={e => setCommitDraft(d => ({ ...d, name: e.target.value }))}
                style={{ ...inp, marginBottom: 7 }}
              />
              {/* Day toggles */}
              <div style={{ display: 'flex', gap: 4, marginBottom: 7, flexWrap: 'wrap' }}>
                {DAYS.map(day => (
                  <button
                    key={day}
                    onClick={() => toggleCommitDay(day)}
                    style={{
                      padding: '4px 7px', fontSize: 10, fontFamily: "'DM Mono', monospace",
                      border: '1px solid var(--border2)', borderRadius: 'var(--radius-sm)', cursor: 'pointer',
                      background: commitDraft.days.includes(day) ? 'var(--accent)' : 'var(--surface)',
                      color: commitDraft.days.includes(day) ? '#fff' : 'var(--fg3)',
                      transition: 'all 0.15s',
                    }}
                  >{day}</button>
                ))}
              </div>
              {/* Time + duration */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 8 }}>
                <div>
                  <FieldLabel>Time</FieldLabel>
                  <input type="time" value={commitDraft.time}
                    onChange={e => setCommitDraft(d => ({ ...d, time: e.target.value }))}
                    style={inpNarrow} />
                </div>
                <div>
                  <FieldLabel>Minutes</FieldLabel>
                  <input type="number" min={5} max={480} value={commitDraft.minutes}
                    onChange={e => setCommitDraft(d => ({ ...d, minutes: +e.target.value }))}
                    style={inpNarrow} />
                </div>
              </div>
              <button onClick={handleAddCommitment} style={{
                width: '100%', padding: '7px', background: 'var(--surface)',
                border: '1px solid var(--border2)', borderRadius: 'var(--radius-sm)',
                fontSize: 11, color: 'var(--fg2)', cursor: 'pointer',
                fontFamily: "'DM Sans', sans-serif", transition: 'all 0.15s',
              }}>Add commitment</button>
              {state.weeklyCommitments.length === 0 && (
                <p style={{ marginTop: 7, fontSize: 10, color: 'var(--fg3)', lineHeight: 1.5 }}>
                  Nothing weekly yet. <span style={{ color: 'var(--fg2)' }}>Sport, work shifts, a standing meeting.</span>
                </p>
              )}
            </div>
          )}

          <Rule />

          {/* ── Settings ── */}
          <SectionToggle label="Settings" expanded={open.settings} onClick={() => toggle('settings')} />
          {open.settings && (
            <div style={{ paddingBottom: 12 }}>
              {/* Day window */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 8 }}>
                <div>
                  <FieldLabel>Day starts</FieldLabel>
                  <input type="time" style={inpNarrow} value={state.settings.day_start}
                    onChange={e => dispatch({ type: 'UPDATE_SETTING', key: 'day_start', value: e.target.value })} />
                </div>
                <div>
                  <FieldLabel>Day ends</FieldLabel>
                  <input type="time" style={inpNarrow} value={state.settings.day_end}
                    onChange={e => dispatch({ type: 'UPDATE_SETTING', key: 'day_end', value: e.target.value })} />
                </div>
              </div>

              {/* Meals */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 8 }}>
                <div>
                  <FieldLabel>Lunch (min)</FieldLabel>
                  <input type="number" style={inpNarrow} min={10} max={90} value={state.settings.lunch_min}
                    onChange={e => dispatch({ type: 'UPDATE_SETTING', key: 'lunch_min', value: +e.target.value })} />
                </div>
                <div>
                  <FieldLabel>Dinner (min)</FieldLabel>
                  <input type="number" style={inpNarrow} min={10} max={90} value={state.settings.dinner_min}
                    onChange={e => dispatch({ type: 'UPDATE_SETTING', key: 'dinner_min', value: +e.target.value })} />
                </div>
              </div>

              {/* Cooking */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 8 }}>
                <div>
                  <FieldLabel>Cooking</FieldLabel>
                  <select style={inpNarrow} value={state.settings.cooking_mode}
                    onChange={e => dispatch({ type: 'UPDATE_SETTING', key: 'cooking_mode', value: e.target.value as Settings['cooking_mode'] })}>
                    <option value="daily">Daily</option>
                    <option value="batch">Batch</option>
                    <option value="none">None</option>
                  </select>
                </div>
                <div>
                  <FieldLabel>Batches / week</FieldLabel>
                  <input type="number" style={inpNarrow} min={1} max={7} value={state.settings.batch_per_week}
                    onChange={e => dispatch({ type: 'UPDATE_SETTING', key: 'batch_per_week', value: +e.target.value })} />
                </div>
              </div>

              {/* Travel */}
              <div style={{ marginBottom: 8 }}>
                <FieldLabel>Travel between locations (min)</FieldLabel>
                <input type="number" style={inp} min={0} max={120} value={state.settings.transition_minutes}
                  onChange={e => dispatch({ type: 'UPDATE_SETTING', key: 'transition_minutes', value: +e.target.value })} />
              </div>

              {/* Lost + free time */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                <div>
                  <FieldLabel>Lost time (%)</FieldLabel>
                  <input type="number" style={inpNarrow} min={0} max={40} value={state.settings.lost_time_pct}
                    onChange={e => dispatch({ type: 'UPDATE_SETTING', key: 'lost_time_pct', value: +e.target.value })} />
                </div>
                <div>
                  <FieldLabel>Free time / day (min)</FieldLabel>
                  <input type="number" style={inpNarrow} min={0} max={240} value={state.settings.free_time_min_per_day}
                    onChange={e => dispatch({ type: 'UPDATE_SETTING', key: 'free_time_min_per_day', value: +e.target.value })} />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Plan button */}
        <div style={{ padding: '12px 16px 16px', borderTop: '1px solid var(--border)', flexShrink: 0 }}>
          <button onClick={handlePlan} disabled={isLoading} style={{
            width: '100%', padding: '10px 16px',
            background: isLoading ? 'var(--surface2)' : 'linear-gradient(135deg, #6366f1, #8b5cf6)',
            border: 'none', borderRadius: 'var(--radius)', color: '#fff',
            fontSize: 12, fontWeight: 600, cursor: isLoading ? 'not-allowed' : 'pointer',
            fontFamily: "'DM Sans', sans-serif", letterSpacing: '-0.01em',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            boxShadow: isLoading ? 'none' : '0 4px 14px rgba(99,102,241,0.35)',
            transition: 'all 0.2s',
          }}>
            {isLoading
              ? <><Spinner />{state.status === 'allocating' ? 'Estimating time…' : 'Placing tasks…'}</>
              : '↗ Plan my week'}
          </button>
        </div>
      </aside>

      {/* ── Main ── */}
      <main style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', background: 'var(--bg)' }}>

        {/* Top bar */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '10px 20px', borderBottom: '1px solid var(--border)',
          background: 'var(--bg2)', flexShrink: 0, gap: 16,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14, flexWrap: 'wrap' }}>
            {(Object.entries(PALETTE) as [BlockType, typeof PALETTE[BlockType]][]).map(([type, p]) => (
              <div key={type} style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                <div style={{ width: 7, height: 7, borderRadius: '50%', background: p.dot, flexShrink: 0 }} />
                <span style={{ fontSize: 10, color: 'var(--fg3)', fontFamily: "'DM Mono', monospace", letterSpacing: '0.03em' }}>{p.label}</span>
              </div>
            ))}
          </div>
          {state.blocks.length > 0 && (
            <button onClick={handleDownload} style={{
              display: 'flex', alignItems: 'center', gap: 6, padding: '5px 13px',
              background: 'var(--surface)', border: '1px solid var(--border2)',
              borderRadius: 'var(--radius-sm)', fontSize: 11, color: 'var(--fg2)',
              cursor: 'pointer', flexShrink: 0, fontFamily: "'DM Sans', sans-serif",
            }}>
              <svg width="11" height="11" viewBox="0 0 11 11" fill="none">
                <path d="M5.5 1v6.5M3 5l2.5 2.5L8 5M1 9.5h9" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              Download .ics
            </button>
          )}
        </div>

        {/* Banners */}
        {state.warnings.length > 0 && (
          <div style={{ padding: '8px 20px', background: 'rgba(245,158,11,0.08)', borderBottom: '1px solid rgba(245,158,11,0.2)', display: 'flex', gap: 8, alignItems: 'flex-start', flexShrink: 0 }}>
            <span style={{ fontSize: 12, flexShrink: 0, marginTop: 1 }}>⚠</span>
            <div style={{ fontSize: 11, color: '#fcd34d', lineHeight: 1.6 }}>
              {state.warnings.map((w, i) => <div key={i}>{w}</div>)}
            </div>
          </div>
        )}
        {state.status === 'error' && state.errorMsg && (
          <div style={{ padding: '8px 20px', background: 'rgba(239,68,68,0.08)', borderBottom: '1px solid rgba(239,68,68,0.2)', display: 'flex', gap: 8, alignItems: 'center', flexShrink: 0 }}>
            <span style={{ fontSize: 12 }}>✕</span>
            <span style={{ fontSize: 11, color: '#fca5a5' }}>{state.errorMsg}</span>
          </div>
        )}

        {/* Calendar */}
        <div style={{ flex: 1, overflow: 'hidden', minHeight: 0 }}>
          <FullCalendar
            plugins={[timeGridPlugin, dayGridPlugin, interactionPlugin]}
            initialView="timeGridWeek"
            headerToolbar={{ left: 'prev,next today', center: 'title', right: '' }}
            events={calEvents()}
            eventContent={(info) => <CalendarEvent info={info} />}
            eventClick={onEventClick}
            height="100%"
            slotMinTime={state.settings.day_start + ':00'}
            slotMaxTime={state.settings.day_end + ':00'}
            nowIndicator allDaySlot={false} expandRows eventDisplay="block"
            slotLabelInterval="01:00"
          />
        </div>
      </main>

      {/* ── Block modal ── */}
      {selected && (
        <div onClick={() => setSelected(null)} style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          zIndex: 1000, backdropFilter: 'blur(4px)',
        }}>
          <div onClick={e => e.stopPropagation()} style={{
            background: 'var(--bg2)', borderRadius: 14, padding: '24px 24px 20px', width: 290,
            boxShadow: '0 30px 80px rgba(0,0,0,0.6), 0 0 0 1px var(--border2)', position: 'relative',
          }}>
            <button onClick={() => setSelected(null)} style={{
              position: 'absolute', top: 14, right: 14, background: 'var(--surface)',
              border: '1px solid var(--border)', borderRadius: 5,
              cursor: 'pointer', color: 'var(--fg3)', padding: '2px 7px', fontSize: 14, lineHeight: 1,
            }}>×</button>
            <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 14 }}>
              <div style={{ width: 8, height: 8, borderRadius: '50%', background: PALETTE[selected.type].dot }} />
              <span style={{ fontSize: 10, fontFamily: "'DM Mono', monospace", color: 'var(--fg3)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                {PALETTE[selected.type].label}{selected.locked && <span style={{ marginLeft: 6, color: PALETTE.task.dot }}>· locked</span>}
              </span>
            </div>
            <p style={{ fontSize: 15, fontWeight: 600, letterSpacing: '-0.02em', marginBottom: 8, color: 'var(--fg)', lineHeight: 1.3 }}>{selected.title}</p>
            <p style={{ fontSize: 11, fontFamily: "'DM Mono', monospace", color: 'var(--fg3)', marginBottom: 16 }}>
              {new Date(selected.start).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} – {new Date(selected.end).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              {' · '}{Math.round((new Date(selected.end).getTime() - new Date(selected.start).getTime()) / 60000)} min
            </p>
            {selected.location && <p style={{ fontSize: 11, color: 'var(--fg2)', marginBottom: 14 }}>📍 {selected.location}</p>}
            {selected.type !== 'event' && (
              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={() => { dispatch({ type: 'REMOVE_BLOCK', id: selected.id }); setSelected(null) }} style={{
                  flex: 1, padding: '8px', background: 'rgba(239,68,68,0.1)',
                  border: '1px solid rgba(239,68,68,0.25)', borderRadius: 'var(--radius-sm)',
                  fontSize: 11, color: '#fca5a5', cursor: 'pointer', fontFamily: "'DM Sans', sans-serif",
                }}>Remove</button>
                <button onClick={() => { dispatch({ type: 'TOGGLE_LOCK', id: selected.id }); setSelected(null) }} style={{
                  flex: 1, padding: '8px',
                  background: selected.locked ? 'rgba(34,197,94,0.1)' : 'var(--surface)',
                  border: `1px solid ${selected.locked ? 'rgba(34,197,94,0.3)' : 'var(--border2)'}`,
                  borderRadius: 'var(--radius-sm)', fontSize: 11,
                  color: selected.locked ? '#86efac' : 'var(--fg2)',
                  cursor: 'pointer', fontFamily: "'DM Sans', sans-serif",
                }}>{selected.locked ? 'Unlock' : 'Lock slot'}</button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

function Spinner() {
  return (
    <svg width="13" height="13" viewBox="0 0 13 13" fill="none" style={{ animation: 'spin 0.75s linear infinite' }}>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      <circle cx="6.5" cy="6.5" r="5" stroke="rgba(255,255,255,0.25)" strokeWidth="2"/>
      <path d="M6.5 1.5a5 5 0 0 1 5 5" stroke="white" strokeWidth="2" strokeLinecap="round"/>
    </svg>
  )
}
